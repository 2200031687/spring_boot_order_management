INSERT INTO orders (product_name, quantity, order_date, customer_name) VALUES 
('Product A', 10, '2024-12-01', 'John Doe'),
('Product B', 5, '2024-12-02', 'Jane Smith'),
('Product C', 20, '2024-12-03', 'Alice Brown');

